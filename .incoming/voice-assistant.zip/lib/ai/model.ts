import { createGoogleGenerativeAI } from '@ai-sdk/google'

// PrepPilot uses Google Gemini for every AI call. GEMINI_API_KEY is the
// project credential name provisioned for this app.
export const google = createGoogleGenerativeAI({
  apiKey: process.env.GEMINI_API_KEY,
})

// Fast, capable multimodal model. Handles text + native PDF understanding.
// We pair it with FAST_THINKING (below) to cap extended reasoning, which keeps
// structured-output latency low instead of the 60s+ that flash models spend on
// deep reasoning by default.
export const PREP_MODEL = google('gemini-3.6-flash')

// Higher-quality model reserved for the most nuanced grading.
export const PREP_MODEL_PRO = google('gemini-pro-latest')

// Text-to-speech model id (used via the REST TTS endpoint).
export const PREP_TTS_MODEL = 'gemini-3.1-flash-tts-preview'

// Provider options that keep Gemient's "thinking" minimal. Gemini 3.x models
// use thinkingLevel ("minimal" | "low" | "medium" | "high") rather than a token
// budget, and reject thinkingBudget outright. Every PrepPilot call produces
// structured JSON where deep reasoning adds large latency for little quality
// gain, so we cap it at "low" for snappy (~1-6s) responses.
export const FAST_THINKING = {
  google: {
    thinkingConfig: { thinkingLevel: 'low' as const, includeThoughts: false },
  },
} as const
